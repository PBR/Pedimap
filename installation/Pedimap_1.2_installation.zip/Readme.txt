Pedimap installation set

This set contains the following files:
Readme.txt
Pedimap.exe
Pedimap.lic
PedimapManual.pdf
Example.pmp
Example.dat

Pedimap requires no specific installation. 
Just copy the files to any directory (a new folder Pedimap
in the Program Files folder would be a logical place)
and double-click to run.

Suggestions and bug reports are welcome at 
roeland.voorrips@wur.nl

Example.pmp is a small Pedimap project and Example.dat the
corresponding datafile. The example is small but contains all 
types of data that pedimap can handle, i.e. textual and numeric 
phenotypic traits, marker scores and Identity-By-Descent (IBD) 
probabilities. The IBD are usually not available (I obtain them 
using the program FlexQTL, see www.flexqtl.nl). Datafiles 
omitting IBD (or other datatypes) are also allowed and obviously 
much simpler.

Pedimap currently runs only under Microsoft Windows (32bit and 
64bit versions).

Citation:
Voorrips RE, Bink MCAM, Van de Weg WE (2012) Pedimap: software
for the visualization of genetic and phenotypic data in Ppdigrees.
J. Hered. 103:903-907. doi:10.1093/jhered/ess060

Roeland Voorrips
Wageningen UR - Plant Breeding
roeland.voorrips@wur.nl 
